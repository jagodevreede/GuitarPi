package org.staccato.maps;

import java.util.HashMap;

public class SolfegeReplacementMap extends HashMap<String, String> {{
	put("DO", "C");
	put("RE", "D");
	put("MI", "E");
	put("FA", "F");
	put("SO", "G");
	put("SOL", "G");
	put("LA", "A");
	put("TI", "B");
	put("TE", "B");
}}

